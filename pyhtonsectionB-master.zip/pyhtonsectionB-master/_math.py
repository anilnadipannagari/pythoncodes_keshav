def factorial():
    pass