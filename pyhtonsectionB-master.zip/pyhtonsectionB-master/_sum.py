a=[1,2,4,5,'4']
out=[]
for i in a:
    if isinstance(i,int):
        out+=i