b=[1,2,3]
def length(a):
    count =0
    for i in a:
        count+=1
    return count,a
    

c=length(b)
print('variable c is :- ',c)
d=len(b)
print('variable d is :- ',d)