class Mca:
    principal='prabhakar naidu'

    
