class Employee:
    company = 'Tesla'
    ceo     = 'Elon Musk'
    
    def __init__(self,name,age,sal,eid):
        self.name = name
        self.age  = age
        self.sal  = sal
        self.eid  = eid


        

bhanu = Employee('bhanu',22,50000,'tes01')

