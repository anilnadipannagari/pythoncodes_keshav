from functools import reduce
a=reduce(lambda a,b:a+b,[1,3,2,4])
print(a)
