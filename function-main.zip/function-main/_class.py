class number:
    a=10
    @classmethod
    def increment(cls):
        cls.a =cls.a+1
        return cls.a
