print(list(filter(lambda a:type(a)in[int,float,complex,bool],[2,5,6,8,10,5,])))

