def add(a,b,d):
    print(a) 
    print(b)
    print(d) 

add(**{'b':34,'c':45,'a':33})


