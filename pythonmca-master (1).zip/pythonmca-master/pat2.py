row = int(input('enter rows:-'))
out=''''''
for i in range(1,row+1):
    out=out+('* '*i)
    out=out+'\n'
with open('pat.txt','w') as file:
    file.write(out)
