print(1,2,3,sep='+',end="=")
print(6)

