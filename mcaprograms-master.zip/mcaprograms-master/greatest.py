num1 = int(input('enter a number1:- '))
num2 = int(input('enter a number2:- '))

if num1>num2:
    print(num1,'is greater than ',num2)
else:
    print(num2,'is greater than ',num1)
print('executed')
