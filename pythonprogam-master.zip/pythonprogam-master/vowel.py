a = input('enter a character :-  ')
if 'A'<= a <='Z': 
    print('it is an uppercase')
else:
    print('not an uppercase')