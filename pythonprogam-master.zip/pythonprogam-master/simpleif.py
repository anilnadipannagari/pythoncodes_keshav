a=eval(input('enter some value to check :- '))
if type(a)== int and a%2==0:
    print('it is an even number')
else:
    print('it is an odd number or not an integer')

print('executed')
