num = int(input('enter number'))
if num>=0:
    print(2*num)
else:
    print(num*num)
    