a='MCA SECTION A 12435SDJ@$%'

for var in a:
    print(var)