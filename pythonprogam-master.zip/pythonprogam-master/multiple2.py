i=1
while i<=50:
    print('2 *',i,'=',2*i)
    i+=1