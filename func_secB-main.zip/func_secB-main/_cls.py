class cname:
    a=10
    b=20

    def __init__(self,x,y):
        self.c=x
        self.d=y

obj=cname(1,2)


