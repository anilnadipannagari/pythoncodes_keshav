import cx_Oracle
conn= cx_Oracle.Connection('Faculty/Faculty@mother')
print(conn)