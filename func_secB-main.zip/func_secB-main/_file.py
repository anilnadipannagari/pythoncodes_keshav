file = open(r"C:\Users\Administrator\Desktop\content.txt",'r',encoding='utf-8')
data = file.read()
print(data)
file.close()

